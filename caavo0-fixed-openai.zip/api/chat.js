import OpenAI from "openai";
const openai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
export default async function handler(req,res){
res.setHeader("Access-Control-Allow-Origin","*");
res.setHeader("Access-Control-Allow-Methods","POST,OPTIONS");
res.setHeader("Access-Control-Allow-Headers","Content-Type");
if(req.method==="OPTIONS") return res.status(200).end();
if(req.method!=="POST") return res.status(405).json({error:"Method"});
try{
const {message}=req.body;
const r=await openai.responses.create({model:"gpt-5.5",input:message,instructions:"Her zaman Türkçe konuş."});
res.status(200).json({reply:r.output_text});
}catch(e){res.status(500).json({error:e.message});}
}